(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888,6485,5792,3748,2988,4163,8030,8385,6200,8720,8493,4255,1542,924,3493,8395,5014,5479,1384,7326,5417,8328,5908,8272,2019,7989,8299,3803,9680,5301,6521,2488,8200,1340];
exports.modules = {

/***/ 24366:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: external "aos"
const external_aos_namespaceObject = require("aos");
var external_aos_default = /*#__PURE__*/__webpack_require__.n(external_aos_namespaceObject);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
;// CONCATENATED MODULE: ./components/common/ScrollTop.jsx


function ScrollToTop() {
    const [isVisible, setIsVisible] = (0,external_react_.useState)(false);
    // Top: 0 takes us all the way back to the top of the page
    // Behavior: smooth keeps it smooth!
    const scrollToTop = ()=>{
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    };
    (0,external_react_.useEffect)(()=>{
        // Button is displayed after scrolling for 500 pixels
        const toggleVisibility = ()=>{
            if (window.pageYOffset > 500) {
                setIsVisible(true);
            } else {
                setIsVisible(false);
            }
        };
        window.addEventListener("scroll", toggleVisibility);
        return ()=>window.removeEventListener("scroll", toggleVisibility);
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: isVisible && /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "scroll-to-top scroll-to-target",
                onClick: scrollToTop,
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "icon icon-arrow-top-right"
                })
            })
        })
    });
}

// EXTERNAL MODULE: ./node_modules/swiper/swiper.min.css
var swiper_min = __webpack_require__(58722);
// EXTERNAL MODULE: ./node_modules/swiper/modules/pagination/pagination.min.css
var pagination_min = __webpack_require__(62996);
// EXTERNAL MODULE: ./node_modules/swiper/modules/navigation/navigation.min.css
var navigation_min = __webpack_require__(69176);
// EXTERNAL MODULE: ./node_modules/swiper/modules/scrollbar/scrollbar.min.css
var scrollbar_min = __webpack_require__(15198);
// EXTERNAL MODULE: ./node_modules/swiper/modules/effect-cards/effect-cards.min.css
var effect_cards_min = __webpack_require__(8936);
// EXTERNAL MODULE: ./node_modules/aos/dist/aos.css
var aos = __webpack_require__(81759);
// EXTERNAL MODULE: ./styles/index.scss
var styles = __webpack_require__(31663);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "@reduxjs/toolkit"
var toolkit_ = __webpack_require__(75184);
// EXTERNAL MODULE: ./features/hero/findPlaceSlice.js
var findPlaceSlice = __webpack_require__(10743);
;// CONCATENATED MODULE: ./app/store.js


const store = (0,toolkit_.configureStore)({
    reducer: {
        hero: findPlaceSlice/* default */.ZP
    }
});

;// CONCATENATED MODULE: ./pages/_app.js













if (false) {}
function App({ Component , pageProps  }) {
    (0,external_react_.useEffect)(()=>{
        external_aos_default().init({
            duration: 1200,
            once: true
        });
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("main", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_redux_.Provider, {
            store: store,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                    ...pageProps
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(ScrollToTop, {})
            ]
        })
    });
}


/***/ }),

/***/ 81759:
/***/ (() => {



/***/ }),

/***/ 8936:
/***/ (() => {



/***/ }),

/***/ 69176:
/***/ (() => {



/***/ }),

/***/ 62996:
/***/ (() => {



/***/ }),

/***/ 15198:
/***/ (() => {



/***/ }),

/***/ 58722:
/***/ (() => {



/***/ }),

/***/ 31663:
/***/ (() => {



/***/ }),

/***/ 75184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 16689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 20997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [743], () => (__webpack_exec__(24366)));
module.exports = __webpack_exports__;

})();