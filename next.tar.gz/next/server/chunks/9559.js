"use strict";
exports.id = 9559;
exports.ids = [9559];
exports.modules = {

/***/ 94139:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "o": () => (/* binding */ tourCategories1)
/* harmony export */ });
const tourCategories1 = [
    {
        id: 1,
        icon: "icon-nature",
        name: "Wildlife Tour",
        tourNumber: "5",
        price: "650",
        dealyAimation: ""
    },
    {
        id: 2,
        icon: "icon-hiking ",
        name: "Adventure Tour",
        tourNumber: "4",
        price: "550",
        dealyAimation: "100"
    },
    {
        id: 3,
        icon: "icon-city ",
        name: "City Tours",
        tourNumber: "8",
        price: "700",
        dealyAimation: "200"
    },
    {
        id: 4,
        icon: "icon-museum ",
        name: "Museum Tours",
        tourNumber: "6",
        price: "800",
        dealyAimation: "300"
    },
    {
        id: 5,
        icon: "icon-beach-umbrella ",
        name: "Beaches Tour",
        tourNumber: "5",
        price: "550",
        dealyAimation: "400"
    },
    {
        id: 6,
        icon: "icon-nature",
        name: "Wildlife Tour",
        tourNumber: "5",
        price: "650",
        dealyAimation: "500"
    },
    {
        id: 7,
        icon: "icon-hiking ",
        name: "Adventure Tour",
        tourNumber: "4",
        price: "550",
        dealyAimation: "600"
    },
    {
        id: 8,
        icon: "icon-city ",
        name: "City Tours",
        tourNumber: "8",
        price: "700",
        dealyAimation: "700"
    },
    {
        id: 9,
        icon: "icon-camping ",
        name: "Camping",
        tourNumber: "5",
        price: "550",
        dealyAimation: "0"
    },
    {
        id: 10,
        icon: "icon-hiking-2 ",
        name: "Trekking",
        tourNumber: "6",
        price: "480",
        dealyAimation: "100"
    },
    {
        id: 11,
        icon: "icon-fire",
        name: "Camp Fire",
        tourNumber: "5",
        price: "550",
        dealyAimation: "200"
    },
    {
        id: 12,
        icon: "icon-jeep",
        name: "Off Road",
        tourNumber: "8",
        price: "660",
        dealyAimation: "300"
    },
    {
        id: 13,
        icon: "icon-traveller ",
        name: "Exploring",
        tourNumber: "8",
        price: "880",
        dealyAimation: "400"
    }
];


/***/ }),

/***/ 47991:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ isTextMatched)
/* harmony export */ });
function isTextMatched(tag, match) {
    if (tag !== undefined && match !== "") {
        if (tag.toLocaleLowerCase() === match.toLocaleLowerCase()) {
            return true;
        }
        return false;
    }
    return false;
}


/***/ })

};
;